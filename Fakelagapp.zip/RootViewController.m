﻿#import "RootViewController.h"
#import <sys/socket.h>
#import <unistd.h>

BOOL isOverlayActive = NO;
BOOL isFakeLagting = NO;
int delayTimeMs = 300;

@interface FloatingMenuWindow : UIWindow
@property (nonatomic, strong) UIButton *logoButton;
@property (nonatomic, strong) UIView *menuExpandedView;
@property (nonatomic, strong) UIButton *btnBatLag;
@property (nonatomic, strong) UIButton *btnTatLag;
@end

static FloatingMenuWindow *floatingWindow = nil;

@implementation RootViewController

- (void)loadView {
    [super loadView];
    self.view.backgroundColor = [UIColor colorWithRed:0.12 green:0.12 blue:0.14 alpha:1.0];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 80, self.view.frame.size.width, 40)];
    titleLabel.text = @"SUDO FAKE LAG CONTROL";
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.font = [UIFont boldSystemFontOfSize:20];
    [self.view addSubview:titleLabel];
    
    UIButton *btnBatMenu = [UIButton buttonWithType:UIButtonTypeCustom];
    btnBatMenu.frame = CGRectMake(40, 200, self.view.frame.size.width - 80, 55);
    btnBatMenu.backgroundColor = [UIColor colorWithRed:0.18 green:0.49 blue:0.20 alpha:1.0];
    btnBatMenu.layer.cornerRadius = 12;
    [btnBatMenu setTitle:@"BẬT HỆ THỐNG" forState:UIControlStateNormal];
    [btnBatMenu addTarget:self action:@selector(actionBatHeThong) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnBatMenu];
    
    UIButton *btnTatMenu = [UIButton buttonWithType:UIButtonTypeCustom];
    btnTatMenu.frame = CGRectMake(40, 280, self.view.frame.size.width - 80, 55);
    btnTatMenu.backgroundColor = [UIColor colorWithRed:0.76 green:0.22 blue:0.22 alpha:1.0];
    btnTatMenu.layer.cornerRadius = 12;
    [btnTatMenu setTitle:@"TẮT & XÓA MENU" forState:UIControlStateNormal];
    [btnTatMenu addTarget:self action:@selector(actionTatHeThong) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnTatMenu];
}

- (void)actionBatHeThong {
    if (!isOverlayActive) {
        isOverlayActive = YES;
        floatingWindow = [[FloatingMenuWindow alloc] init];
        [[UIApplication sharedApplication] performSelector:@selector(suspend)];
    }
}

- (void)actionTatHeThong {
    if (isOverlayActive) {
        isOverlayActive = NO;
        isFakeLagting = NO;
        floatingWindow.hidden = YES;
        floatingWindow = nil;
    }
}
@end

@implementation FloatingMenuWindow
- (instancetype)init {
    self = [super initWithFrame:CGRectMake(40, 150, 60, 60)];
    if (self) {
        self.windowLevel = UIWindowLevelAlert + 1999;
        self.backgroundColor = [UIColor clearColor];
        self.hidden = NO;
        
        self.logoButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.logoButton.frame = CGRectMake(0, 0, 60, 60);
        self.logoButton.backgroundColor = [UIColor colorWithRed:0.90 green:0.45 blue:0.10 alpha:1.0];
        self.logoButton.layer.cornerRadius = 15;
        self.logoButton.layer.borderWidth = 2;
        self.logoButton.layer.borderColor = [UIColor whiteColor].CGColor;
        [self.logoButton setTitle:@"FF" forState:UIControlStateNormal];
        self.logoButton.titleLabel.font = [UIFont boldSystemFontOfSize:20];
        [self.logoButton addTarget:self action:@selector(logoClicked) forControlEvents:UIControlEventTouchUpInside];
        
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
        [self.logoButton addGestureRecognizer:pan];
        [self addSubview:self.logoButton];
        
        self.menuExpandedView = [[UIView alloc] initWithFrame:CGRectMake(65, 0, 140, 130)];
        self.menuExpandedView.backgroundColor = [UIColor colorWithRed:0.08 green:0.08 blue:0.10 alpha:0.95];
        self.menuExpandedView.layer.cornerRadius = 10;
        self.menuExpandedView.hidden = YES;
        
        UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, 140, 20)];
        lblTitle.text = @"FAKE LAG MENU";
        lblTitle.textColor = [UIColor orangeColor];
        lblTitle.font = [UIFont boldSystemFontOfSize:12];
        lblTitle.textAlignment = NSTextAlignmentCenter;
        [self.menuExpandedView addSubview:lblTitle];
        
        self.btnBatLag = [UIButton buttonWithType:UIButtonTypeCustom];
        self.btnBatLag.frame = CGRectMake(10, 35, 120, 35);
        self.btnBatLag.backgroundColor = [UIColor colorWithRed:0.20 green:0.20 blue:0.25 alpha:1.0];
        [self.btnBatLag setTitle:@"Bật Lag" forState:UIControlStateNormal];
        [self.btnBatLag setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        self.btnBatLag.titleLabel.font = [UIFont systemFontOfSize:14];
        [self.btnBatLag addTarget:self action:@selector(kickHoatLag) forControlEvents:UIControlEventTouchUpInside];
        [self.menuExpandedView addSubview:self.btnBatLag];
        
        self.btnTatLag = [UIButton buttonWithType:UIButtonTypeCustom];
        self.btnTatLag.frame = CGRectMake(10, 80, 120, 35);
        self.btnTatLag.backgroundColor = [UIColor colorWithRed:0.60 green:0.15 blue:0.15 alpha:1.0];
        [self.btnTatLag setTitle:@"Tắt Lag" forState:UIControlStateNormal];
        [self.btnTatLag setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        self.btnTatLag.titleLabel.font = [UIFont systemFontOfSize:14];
        [self.btnTatLag addTarget:self action:@selector(ngungLag) forControlEvents:UIControlEventTouchUpInside];
        [self.menuExpandedView addSubview:self.btnTatLag];
        
        [self addSubview:self.menuExpandedView];
    }
    return self;
}

- (void)logoClicked {
    if (self.menuExpandedView.hidden) {
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, 210, 130);
        self.menuExpandedView.hidden = NO;
    } else {
        self.menuExpandedView.hidden = YES;
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, 60, 60);
    }
}

- (void)handlePan:(UIPanGestureRecognizer *)sender {
    CGPoint translation = [sender translationInView:self];
    self.center = CGPointMake(self.center.x + translation.x, self.center.y + translation.y);
    [sender setTranslation:CGPointZero inView:self];
}

- (void)kickHoatLag {
    isFakeLagting = YES;
    [self.btnBatLag setBackgroundColor:[UIColor greenColor]];
    [self.btnBatLag setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btnBatLag setTitle:@"Đang Lag..." forState:UIControlStateNormal];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        while (isFakeLagting) {
            usleep(delayTimeMs * 1000); 
            usleep(10000);
        }
    });
}

- (void)ngungLag {
    isFakeLagting = NO;
    [self.btnBatLag setBackgroundColor:[UIColor colorWithRed:0.20 green:0.20 blue:0.25 alpha:1.0]];
    [self.btnBatLag setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.btnBatLag setTitle:@"Bật Lag" forState:UIControlStateNormal];
}
@end
